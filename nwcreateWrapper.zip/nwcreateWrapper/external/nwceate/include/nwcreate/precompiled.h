#pragma once

#include <shared/basic_precompiled.h>

#include <lcutil/LcUDict.h>
#include <lcutil/LcUSysDynamicLib.h>
#include <lcutil/LcUGuid.h>
#include <lcutil/LcUSchema.h>

#include <lcogl/LcOglTextNode.h>
#include <lcogl/LcOglExternalGeometry.h>
#include <lcogl/LcOglJsonProteinAsset.h>

#include <lcodapi/LcOaPartition.h>
#include <lcodapi/LcOaLight.h>
#include <lcodapi/LcOaGeometry.h>
#include <lcodapi/LcOaPresenterAttribute.h>

#include <lcodgraph/LcOgBRepHandle.h>
#include <lcodgraph/LcOgCurves.h>
#include <lcodgraph/LcOgCurves2d.h>
#include <lcodgraph/LcOgSurfaces.h>
#include <lcodgraph/LcOgTopology.h>
#include <lcodgraph/LcOgBRepProfileBuilder.h>
#include <lcodgraph/LcOgBRepImporter.h>

#include <lcplot/LcPlBrush.h>
#include <lcplot/LcPlGeometryBrush.h>
#include <lcplot/LcPlHatchBrush.h>
#include <lcplot/LcPlVertexColorBrush.h>
#include <lcplot/LcPlImageBrush.h>
#include <lcplot/LcPlLinearGradientBrush.h>
#include <lcplot/LcPlRadialGradientBrush.h>
#include <lcplot/LcPlSolidColorBrush.h>

#include <lcodyplugin/LcOpProgress.h>
#include <lcodyplugin/LcOpView.h>
#include <lcodyplugin/LcOpFormatPlugins.h>
#include <lcodyplugin/LcOpGridSystem.h>
#include <lcodyplugin/LcOpSelectionSet.h>
#include <lcodyplugin/LcOpTextureSpace.h>
